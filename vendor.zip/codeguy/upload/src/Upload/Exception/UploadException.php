<?php
namespace Upload\Exception;

class UploadException extends \RuntimeException
{

}
